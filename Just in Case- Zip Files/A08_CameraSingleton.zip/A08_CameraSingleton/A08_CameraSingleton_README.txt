Madison Smith and Karen Navarro worked on this assignment :)

Repo Address:https://github.com/Kayna36/DSA2HW.git